#!/bin/bash
grep -q "Victim accepted fake block" /shared/attack_log.txt && echo "Y" || echo "N"
