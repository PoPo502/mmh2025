#!/bin/bash
grep -q "fix successfully" /shared/attack_log.txt && echo "Y" || echo "N"
