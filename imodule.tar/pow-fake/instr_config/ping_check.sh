#!/bin/bash
grep -q "Ping to victim successful" /shared/attack_log.txt && echo "Y" || echo "N"
